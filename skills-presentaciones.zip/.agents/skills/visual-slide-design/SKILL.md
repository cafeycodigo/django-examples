---
name: visual-slide-design
description: Design or refine slide composition, typography, color, hierarchy and visual storytelling for professional presentations, including reusable design tokens and layout guidance.
---

# Diseño visual de diapositivas
Define un sistema visual adaptado a la audiencia, soporte y marca. Reutiliza la plantilla o referencia proporcionada antes de elegir otro estilo. Para diseñar sin referencia, usa [assets/theme.json](assets/theme.json) como punto de partida editable, no como identidad obligatoria.

Elige el tipo de composición según la información: comparación con columnas alineadas, proceso con pasos conectados, evidencia con gráfico y anotaciones, explicación con diagrama y texto cercano. Evita aplicar tarjetas o listas a todas las diapositivas. La portada puede tener una dirección visual distinta sin romper la tipografía y paleta del conjunto.

Usa una retícula y márgenes consistentes. En lienzo 1280×720, empieza con márgenes de 64 px, títulos de 40–48 px y cuerpo de 26–32 px; ajusta al contexto de proyección. Son puntos de partida, no límites para plantillas existentes. Si falta espacio, edita el contenido o divide la explicación antes de reducir la letra. Verifica fuentes instaladas y usa `typeface` en la API de Artifact Tool.

Limita la paleta funcional y reserva un acento para el foco. No dependas solo del color para expresar categorías. Ejecuta `python scripts/check_theme.py assets/theme.json` para contrastes de los pares configurados. El umbral 4.5:1 es una comprobación conservadora para texto; el resultado no mide el contraste de fotos, gradientes, transparencias ni temas sustituidos en PowerPoint.

Comprueba recorte de imágenes, proporciones y resolución al tamaño final. Usa objetos nativos para información que deba editarse; evita adornos que compitan con el mensaje. Renderiza e inspecciona el conjunto a tamaño real y en miniaturas para comprobar jerarquía, ritmo y coherencia. Para exportar PPTX utiliza el flujo de presentaciones disponible; esta habilidad de diseño no reemplaza su motor.
