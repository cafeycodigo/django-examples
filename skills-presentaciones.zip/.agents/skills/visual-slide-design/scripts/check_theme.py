import argparse, json
def luminance(color):
    value=color.lstrip('#')
    if len(value)!=6: raise ValueError('Use six-digit RGB colors')
    rgb=[int(value[i:i+2],16)/255 for i in (0,2,4)]
    rgb=[v/12.92 if v<=0.04045 else ((v+0.055)/1.055)**2.4 for v in rgb]
    return sum(a*b for a,b in zip(rgb,(0.2126,0.7152,0.0722)))
def main():
    parser=argparse.ArgumentParser();parser.add_argument('theme');args=parser.parse_args()
    theme=json.load(open(args.theme,encoding='utf-8'));results=[]
    for fg,bg in theme['contrastPairs']:
        a,b=sorted([luminance(theme[fg]),luminance(theme[bg])]);ratio=(b+0.05)/(a+0.05)
        results.append(dict(foreground=fg,background=bg,ratio=round(ratio,2),passNormalText=ratio>=4.5))
    print(json.dumps(results,indent=2));return 0 if all(r['passNormalText'] for r in results) else 1
if __name__=='__main__': raise SystemExit(main())
