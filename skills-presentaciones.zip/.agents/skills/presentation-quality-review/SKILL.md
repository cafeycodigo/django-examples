---
name: presentation-quality-review
description: Review and correct PowerPoint slide quality through automated PPTX package checks and rendered visual inspection; report findings with slide numbers and verify the corrected deck.
---

# Revisión y corrección de presentaciones
Conserva el original y comprende la intención y plantilla antes de cambiar el diseño. Revisa contenido, editabilidad, legibilidad y composición. Una solicitud de revisión no autoriza reescribir la marca o eliminar información necesaria.

Ejecuta `python scripts/review_pptx.py archivo.pptx --out informe.json`. Requiere Python 3 estándar. Comprueba estructura ZIP/XML, relaciones internas, cantidad de diapositivas, cuadros de texto fuera del lienzo y fragmentos vacíos. Sus advertencias son indicios; no calcula ajuste tipográfico, herencia completa de estilos, grupos transformados ni solapamientos visuales.

Usa además los verificadores de integridad y geometría del motor instalado cuando estén disponibles. Renderiza todas las diapositivas con el motor de origen o un renderizador de PowerPoint/LibreOffice verificado. Si no hay renderizador, informa que la revisión visual está pendiente; no declares aprobación visual por pasar el análisis XML.

Inspecciona las imágenes renderizadas, en vista de conjunto y detalle: texto cortado, superposición accidental, contraste, espacios, alineación, distorsión de imágenes, ejes y etiquetas de gráficos. Comprueba también notas, fuentes, cifras y adecuación a la audiencia. Usa [assets/review-template.json](assets/review-template.json) para registrar hallazgos concretos, severidad, evidencia y resolución.

Corrige preferentemente en el código fuente o el documento editable con la API apropiada. Conserva gráficos y texto nativos. No reduzcas toda la tipografía ni cambies la plantilla para silenciar un aviso. Documenta excepciones intencionales. Nunca ejecutes macros u objetos incrustados durante una inspección.

Vuelve a exportar y renderizar las diapositivas corregidas, y verifica el conjunto tras cambios de tema o estructura. Si el mismo problema persiste después de dos intentos, cambia el enfoque y declara cualquier limitación pendiente. Entrega el archivo corregido si se solicitó y un resumen de hallazgos materiales; diferencia comprobaciones automáticas, revisión visual y prueba en PowerPoint.
