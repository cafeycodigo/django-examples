import argparse, json, posixpath, re, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
def review(file):
    issues=[];slides=[]
    with zipfile.ZipFile(file) as z:
        bad=z.testzip()
        if bad: issues.append(dict(severity='error',message=f'CRC failure: {bad}'))
        names=set(z.namelist())
        for required in ('[Content_Types].xml','_rels/.rels','ppt/presentation.xml'):
            if required not in names: issues.append(dict(severity='error',message=f'Missing {required}'))
        if 'ppt/presentation.xml' not in names: return dict(issues=issues,slides=[],visualReviewComplete=False)
        roots={}
        for name in names:
            if name.endswith(('.xml','.rels')):
                raw=z.read(name)
                if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw: raise ValueError('DTD/entity declarations not supported')
                try: roots[name]=ET.fromstring(raw)
                except ET.ParseError as e: issues.append(dict(severity='error',message=f'Malformed {name}: {e}'))
        for name,root in roots.items():
            if not name.endswith('.rels'): continue
            base=posixpath.dirname(posixpath.dirname(name))
            for rel in root:
                target=rel.get('Target','')
                if rel.get('TargetMode')=='External' or not target: continue
                target=target.split('#')[0]
                if not target: continue
                resolved=posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(base,target))
                if resolved not in names: issues.append(dict(severity='error',message=f'Broken relationship {name}: {resolved}'))
        size=roots['ppt/presentation.xml'].find('p:sldSz',NS)
        width,height=int(size.get('cx')),int(size.get('cy'))
        files=sorted((n for n in names if re.fullmatch(r'ppt/slides/slide\d+\.xml',n)),key=lambda n:int(re.search(r'slide(\d+)',n)[1]))
        for name in files:
            root=roots.get(name)
            if root is None: continue
            slide=int(re.search(r'slide(\d+)',name)[1]);texts=root.findall('.//a:t',NS)
            slides.append(dict(part=name,textRuns=len(texts)))
            if not texts: issues.append(dict(slide=slide,severity='warning',message='No native text; verify intended editability'))
            # Direct shapes only; grouped shapes require transformed geometry from the authoring engine.
            for shape in root.findall('p:cSld/p:spTree/p:sp',NS):
                if shape.find('p:txBody',NS) is None: continue
                transform=shape.find('p:spPr/a:xfrm',NS)
                if transform is None: continue
                off,ext=transform.find('a:off',NS),transform.find('a:ext',NS)
                if off is None or ext is None: continue
                x,y,cx,cy=[int(v) for v in (off.get('x'),off.get('y'),ext.get('cx'),ext.get('cy'))]
                if x<0 or y<0 or x+cx>width+10 or y+cy>height+10: issues.append(dict(slide=slide,severity='warning',message='Text shape extends beyond canvas; inspect render'))
    if not slides: issues.append(dict(severity='error',message='No slide parts found'))
    return dict(slideCount=len(slides),slides=slides,issues=issues,visualReviewComplete=False,limitations=['No text-fit, overlap, style inheritance or grouped-transform analysis'])
def main():
    parser=argparse.ArgumentParser();parser.add_argument('pptx');parser.add_argument('--out');args=parser.parse_args()
    result=review(args.pptx);text=json.dumps(result,ensure_ascii=False,indent=2)
    if args.out:
        with open(args.out,'x',encoding='utf-8') as f: f.write(text+'\n')
    print(text);return int(any(i['severity']=='error' for i in result['issues']))
if __name__=='__main__': raise SystemExit(main())
