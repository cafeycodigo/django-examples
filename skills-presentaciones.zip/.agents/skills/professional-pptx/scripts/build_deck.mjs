import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const [specPath, buildPath] = process.argv.slice(2);
if (!specPath || !buildPath || !process.env.ARTIFACT_TOOL_ENTRY) {
  throw new Error('Usage: node build_deck.mjs spec.json NEW_BUILD_DIR; set ARTIFACT_TOOL_ENTRY to the runtime module');
}
const spec = JSON.parse(await fs.readFile(specPath, 'utf8'));
if (!Array.isArray(spec.slides) || !spec.slides.length) throw new Error('slides must be a nonempty array');
const {Presentation, PresentationFile} = await import(pathToFileURL(path.resolve(process.env.ARTIFACT_TOOL_ENTRY)).href);
await fs.mkdir(buildPath); // Fail if destination already exists; preserve previous output.
const p = Presentation.create({slideSize:{width:1280,height:720}});
const t = {background:'#F6F8FB',ink:'#102238',accent:'#176B87',typeface:'Arial',titleSize:44,bodySize:28,...spec.theme};
function text(slide,value,x,y,w,h,size,color) {
  const shape=slide.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
  shape.text=String(value);shape.text.style={typeface:t.typeface,fontSize:size,color};
}
for (const [i,data] of spec.slides.entries()) {
  if (typeof data.title !== 'string' || !Array.isArray(data.rows) || data.rows.length>4) throw new Error(`Slide ${i+1}: title and at most four rows required; split or customize layout`);
  const s=p.slides.add();s.background.fill=t.background;
  text(s,data.title,64,48,1152,120,t.titleSize,t.ink);
  data.rows.forEach((row,j)=>text(s,row,64,205+j*96,1152,84,t.bodySize,t.ink));
  text(s,String(i+1),1160,662,56,30,18,t.accent);
  s.speakerNotes.text=data.notes||'';
  const png=await p.export({slide:s,format:'png',scale:1});
  await fs.writeFile(path.join(buildPath,`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()),{flag:'wx'});
}
await (await PresentationFile.exportPptx(p)).save(path.join(buildPath,'draft.pptx'));
console.log(JSON.stringify({draft:path.resolve(buildPath,'draft.pptx'),slides:p.slides.items.length,visualReview:'pending',finalization:'pending'}));
