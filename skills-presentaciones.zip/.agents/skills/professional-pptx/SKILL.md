---
name: professional-pptx
description: Create and edit editable PowerPoint PPTX files with native text, shapes, tables and charts; preserve source templates and deliver validated files with reproducible authoring sources.
---

# PowerPoint editable
Produce archivos .pptx y conserva texto, diagramas, tablas y gráficos como objetos nativos cuando la API lo permita. Usa imágenes para fotografías o ilustraciones; no conviertas diapositivas completas en imágenes.

Confirma audiencia, objetivo, duración y material de referencia solo cuando no puedan inferirse. Respeta idioma, marca, orden y extensión solicitados. Inspecciona primero los archivos usados como plantilla y conserva sus dimensiones y estilos.

## Motor y preparación
Usa JavaScript local con `@oai/artifact-tool`. En Codex desktop localiza el runtime con `load_workspace_dependencies` y lee la habilidad instalada `presentations:Presentations`, especialmente `references/implementation.md`, el quick start y `references/finalization.md`. Esta habilidad solicita explícitamente un archivo PPTX; no necesita crear una presentación en un servicio remoto. Si el motor o las instrucciones no están disponibles, identifica la dependencia faltante antes de prometer una exportación. No instales sustitutos ni modifiques la caché del runtime.

El ejemplo [assets/deck.json](assets/deck.json) define una presentación mínima. El ejecutor `scripts/build_deck.mjs` recibe `spec.json` y un directorio nuevo de construcción; requiere `ARTIFACT_TOOL_ENTRY` con la ruta absoluta al módulo del runtime. Exporta un borrador editable y PNG por diapositiva. Es un punto de partida, no una plantilla universal ni un finalizador. Personaliza los diseños mediante la API para fotografías, gráficos y tablas; no fuerces todo el contenido al formato de filas del ejemplo. No sobreescribe archivos.

## Producción
Prepara una secuencia de diapositivas con propósito claro. Selecciona fuentes realmente disponibles, cita los datos en notas del presentador y conserva fuentes y licencias de imágenes. Para datos inciertos, indica la incertidumbre; no inventes cifras o referencias.

Antes de autoría ejecuta el marcador de operación de la habilidad de presentaciones cuando esté disponible. Construye en un directorio privado, exporta y renderiza. Inspecciona todas las diapositivas; corrige recortes, saltos, contraste y contenido antes de ejecutar el finalizador oficial con política de fuentes y verificadores de integridad y geometría. Si un fallo de sistema impide finalizar, informa el bloqueo; no publiques un borrador como validado.

Entrega el PPTX final. Conserva el código, entradas y recursos en el proyecto para reproducirlo; enlázalos solo si el usuario los solicita. Distingue revisión de PNG de una prueba real en Microsoft PowerPoint.
