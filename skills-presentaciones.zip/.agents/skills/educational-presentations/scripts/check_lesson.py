import argparse, json
def main():
    parser=argparse.ArgumentParser();parser.add_argument('lesson');args=parser.parse_args()
    data=json.load(open(args.lesson,encoding='utf-8'));issues=[]
    ids=[o['id'] for o in data['objectives']]
    if not ids or len(set(ids))!=len(ids): issues.append('Objectives must have unique, nonempty IDs')
    for category in ('activities','assessments'):
        covered=set()
        for item in data.get(category,[]):
            refs=set(item.get('objectives',[]));covered.update(refs)
            if refs-set(ids): issues.append(f'{category}: unknown objective references')
            if category=='activities' and (not item.get('instructions') or not item.get('solution')): issues.append('Activity needs instructions and solution')
            if category=='assessments' and not item.get('expectedAnswer'): issues.append('Assessment needs expectedAnswer')
        for missing in set(ids)-covered: issues.append(f'{missing}: missing {category}')
    if sum(a.get('minutes',0) for a in data.get('activities',[]))>data['durationMinutes']: issues.append('Activities exceed class duration')
    print(json.dumps(dict(issues=issues,coverageValid=not issues),ensure_ascii=False,indent=2));return bool(issues)
if __name__=='__main__': raise SystemExit(main())
