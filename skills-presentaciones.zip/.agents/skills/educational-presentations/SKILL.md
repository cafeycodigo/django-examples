---
name: educational-presentations
description: Plan and write teaching slide decks with measurable learning goals, progressive examples, readable code, exercises, answers and instructor notes aligned to the audience.
---

# Presentaciones educativas
Identifica nivel previo, resultados observables de aprendizaje y tiempo de clase. Mantén el idioma y los objetivos del usuario. No presupongas conocimientos avanzados ni impongas una cantidad fija de diapositivas.

Organiza la explicación con un problema concreto, un modelo conceptual, un ejemplo resuelto, práctica y comprobación de comprensión. Ajusta la secuencia al tema: no todos los cursos necesitan código ni la misma estructura. Distingue material para estudiantes de soluciones y notas del docente.

Usa [assets/lesson.json](assets/lesson.json) para planificar objetivos y su evidencia. Ejecuta `python scripts/check_lesson.py ruta/al/lesson.json` para detectar objetivos sin práctica ni evaluación. El script comprueba cobertura, no exactitud ni calidad pedagógica; revisa si la actividad realmente demuestra el aprendizaje.

En clases técnicas muestra fragmentos ejecutables pequeños, archivos y versiones pertinentes, entradas, salida esperada y explicación de las líneas decisivas. Verifica el código en un entorno apropiado cuando sea posible e indica qué se ejecutó. No expongas claves ni datos personales. Separa pseudocódigo de código funcional. Divide bloques largos y evita capturas de código que deba copiarse o editarse.

Formula ejercicios con consigna, tiempo estimado, criterios de éxito y solución razonada en notas o anexo. Incluye errores frecuentes y preguntas que permitan explicar decisiones, no solo repetir definiciones. Cita documentación y fuentes de hechos especializados; revisa vigencia de APIs y versiones.

Ajusta el contenido al tiempo disponible con pausas y práctica. Para el PPTX editable sigue la habilidad de presentaciones instalada o `professional-pptx` si está disponible. Conserva objetivos, ejercicios y notas durante las correcciones visuales.
